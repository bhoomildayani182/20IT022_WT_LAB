let scores = [80, 90, 70];
console.log("Using For..of Looping");
for (let score of scores) {
score = score + 5;
console.log(score);

let z = [10,20,30];
z.message = 'Hi';

console.log("for...in:");
for (let zs in z) {
console.log(z); 
}

}
const person = {
firstName: "John",
lastName: "Doe",
id: 5566,
fullName : function() {
return this.firstName + " " + this.lastName;
}
};

// Display data from the object:
document.getElementById("demo").innerHTML = person.fullName();
function basicFunction () {
alert ("Hello JavaScripters!, welcome()");
}

basicFunction();
let str = "Apple, Banana, Kiwi";
let part = str.slice(7, 13);

let t = "Apple, Banana, Kiwi";
let z = t.substring(7, 13);
let text = "Please visit Microsoft!";
let newText = text.replace("Microsoft", "W3Schools");

let text1 = "Hello";
let text2 = "World";
let text3 = text1.concat(" ", text2);
const cars = [];
cars[0]= "Saab";
cars[1]= "Volvo";
cars[2]= "BMW";
document.getElementById("hi").innerHTML = cars;
let x = 3.14;
let y = 3;
document.getElementById("demo").innerHTML = x + "<br>" + y;